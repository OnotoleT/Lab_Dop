/* tslint:disable */
/* eslint-disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL mutation operation: login
// ====================================================

export interface login {
  login: string | null;
}

export interface loginVariables {
  email: string;
}
