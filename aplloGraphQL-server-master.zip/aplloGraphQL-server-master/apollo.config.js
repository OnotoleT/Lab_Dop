module.exports = {
    client: {
        name: 'Space Explorer [web]',
        service: "Space Explorer",
    }
  };